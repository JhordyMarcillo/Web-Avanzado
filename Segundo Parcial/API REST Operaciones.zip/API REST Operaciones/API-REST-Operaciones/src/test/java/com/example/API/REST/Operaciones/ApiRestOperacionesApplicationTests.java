package com.example.API.REST.Operaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestOperacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
