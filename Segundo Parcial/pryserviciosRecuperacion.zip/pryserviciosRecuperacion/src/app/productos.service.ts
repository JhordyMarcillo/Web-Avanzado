import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  private Url: string = 'https://drive.google.com/uc?export=download&id=1GU7dq8MRVIi71O8dNqo3Tomqr7mX6e_b';

  constructor(private http: HttpClient) {}

  getProductos(): Observable<any> {
    return this.http.get<any>(this.Url);
  }
}