package com.example.mvc.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
