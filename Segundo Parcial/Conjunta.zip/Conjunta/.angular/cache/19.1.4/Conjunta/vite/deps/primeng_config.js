import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-3XJ5Y4BZ.js";
import "./chunk-YEHP4MLG.js";
import "./chunk-VLH5KT5N.js";
import "./chunk-G65NG6OJ.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
