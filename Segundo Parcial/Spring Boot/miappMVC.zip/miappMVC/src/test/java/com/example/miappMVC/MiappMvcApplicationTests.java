package com.example.miappMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiappMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
